<footer class="footer">
  <p class="footer-ttl">estra, inc.</p>
</footer><?php /**PATH /Users/rin/Desktop/atte/resources/views/components/footer.blade.php ENDPATH**/ ?>