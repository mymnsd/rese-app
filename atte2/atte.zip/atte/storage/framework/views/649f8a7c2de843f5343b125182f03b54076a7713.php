<?php $__env->startSection('main'); ?>
<?php if(session('result')): ?>
<div class="flash_message">
    <?php echo e(session('result')); ?>

</div>
<?php endif; ?>
<?php if( Auth::check() ): ?>
<p class="welcome"><?php echo e(Auth::user()->name); ?>さんお疲れ様です！</p>
<?php endif; ?>
<div class="card-container">
    <?php if(!isset($is_attendance_start)): ?>
    <a href="/attendance/start" class="attendance-btn">勤務開始</a>
    <?php else: ?>
    <p class="attendance-btn inactive">勤務開始</p>
    <?php endif; ?>

    <?php if(!isset($is_attendance_end)): ?>
    <a href="/attendance/end" class="attendance-btn">勤務終了</a>
    <?php else: ?>
    <p class="attendance-btn inactive">勤務終了</p>
    <?php endif; ?>

    <?php if(isset($is_rest)): ?>
    <?php if(!$is_rest): ?>
    <a href="/break/start" class="attendance-btn">休憩開始</a>
    <?php else: ?>
    <p class="attendance-btn inactive">休憩開始</p>
    <?php endif; ?>
    <?php endif; ?>

    <?php if(isset($is_rest)): ?>
    <?php if($is_rest): ?>
    <a href="/break/end" class="attendance-btn">休憩終了</a>
    <?php else: ?>
    <p class="attendance-btn inactive">休憩終了</p>
    <?php endif; ?>
    <?php endif; ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rin/Desktop/atte/resources/views/index.blade.php ENDPATH**/ ?>