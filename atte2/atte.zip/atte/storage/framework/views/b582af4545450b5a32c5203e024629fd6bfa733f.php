<?php $__env->startSection('main'); ?>
<div class="date-container">
    <a class="arrow" href="<?php echo '/attendance/' . ($num - 1); ?>">&lt;</a>
    <p class="date"><?php echo e($fixed_date); ?></p>
    <a class="arrow" href="<?php echo '/attendance/' . ($num + 1); ?>">&gt;</a>
</div>
<table>
    <tr>
        <th>名前</th>
        <th>勤務開始</th>
        <th>勤務終了</th>
        <th>休憩時間</th>
        <th>勤務時間</th>
    </tr>
    <?php $__currentLoopData = $adjustAttendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($attendance->users->name); ?></td>
        <td><?php echo e($attendance->start_time); ?></td>
        <td><?php echo e($attendance->end_time); ?></td>
        <td><?php echo e($attendance->rest_sum); ?></td>
        <td><?php echo e($attendance->work_time); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php echo e($adjustAttendances->links('pagination::default')); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rin/Desktop/atte/resources/views/attendance.blade.php ENDPATH**/ ?>