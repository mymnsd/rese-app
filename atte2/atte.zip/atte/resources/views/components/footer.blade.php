<footer class="footer">
  <p class="footer-ttl">estra, inc.</p>
</footer>